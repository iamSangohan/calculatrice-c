#include "somme.h"

int somme(int a, int b){
    int somme = a+b;
    return somme;
}