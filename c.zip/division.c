#include "division.h"

double division(int a, int b){
    double division = (double)a/b;
    return division;
}