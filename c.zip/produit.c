#include "produit.h"

int produit(int a, int b){
    int produit = a*b;
    return produit;
}