#include "soustraction.h"

int soustraction(int a, int b){
    int soustraction = a-b;
    return soustraction;
}